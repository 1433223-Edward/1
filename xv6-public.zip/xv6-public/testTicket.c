#include "types.h"
#include "stat.h"
#include "user.h"
int main (int argc,char *argv[])
{
    int number = atoi(argv[1]);//字符串变整数
    settickets(number);
    while(1)
    {
        //just for delay
    }
    exit();
}